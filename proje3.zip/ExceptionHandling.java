import java.util.Scanner;

public class ExceptionHandling {
	

	public static void main(String[] args) throws MyExpection {
		// TODO Auto-generated method stub
		
		Scanner dyg = new Scanner(System.in);
		int[] array;
		
		System.out.println("Please Enter the size of the array (small number is recommended: ");
		int number=dyg.nextInt();
		System.out.println();
		String [] cities= new String[number];
		
		String [] city= new String[number];
		System.out.println("Enter the city names and put 'end' at the end.");
		try{
			for(int i=0; i<cities.length; i++) {
				city[i]=dyg.next();
				if(city[i].equalsIgnoreCase("end"))
					break;
			}
		
		String name=dyg.nextLine();
		System.out.println("Please enter the index of letter to read from first city name:");
		int numb =dyg.nextInt();
		System.out.println();
		System.out.println(cities[numb].charAt(numb));
		System.out.println("Please enter a value to divide 25.");
		int numb2=dyg.nextInt();
		System.out.println();
		System.out.println( 25/numb2);
		System.out.println(numb2);		
		System.out.println("Please write a something to call myMethod.");
		String some=dyg.next();
		System.out.println();
		MyExpection.MyMethod(some);
		
	} catch (ArrayIndexOutOfBoundsException firstARR) {
		System.out.println("The values are more than the size of the array.Index "+ number+"2 out of bounds for length"+number);
	} catch (StringIndexOutOfBoundsException String) {
		System.out.println("The index is greater than the length of the string. String index out of range:");
	} catch (NumberFormatException numb) {
		System.out.println("Size is not numeric. For input string:"+numb);
	} catch (ArithmeticException aritmetik) {
		System.out.println("You tried to divide a number with zero. / by zero"+aritmetik.getMessage());
	} finally {
		System.out.println("This code block always runs");
		System.out.println("...");
	}}}


