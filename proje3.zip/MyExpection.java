
public class MyExpection extends Exception {

	
		public static void MyMethod (String d) throws MyExpection {
			
			MyExpection a = new MyExpection();
			
			if (d.substring(0, 1).equalsIgnoreCase(d.substring(d.length()-1))) {
				throw a;
			}
			else 	{
				System.out.println("No exception.");
			}
		}}
