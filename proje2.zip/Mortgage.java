package d;

public class Mortgage {
		
		double interest= 0.3005,
				risk;

		public double calculateInterestMortgage(int capital, Person person) {
			this.interest=(capital+this.risk)*(this.interest+0.9);
			
			return 
					
					this.interest;
		}
		
		public double creditRiskFeeMortgage(int age, double capital) {
			if(age>55) 
			{
				this.risk=0;
			}
			else {
				
				this.risk = (age-55)*0.01*capital*(this.interest/12);
			}
		
			
		public double creditRiskFee(int age, double capital) {
		
			
			return capital;
			
		}

		public void restructuringLoan(int newMonthNumber, Person person, double...remainingInstallments) {
			// TODO Auto-generated method stub
			
			
			double x= remainingInstallments.length*remainingInstallments[0];
			
			double y= person.installment-x;
			
			System.out.println("New Mortgage Loan Repayment will be: " + y);
			System.out.println("Your new payments will be: "+ (y/newMonthNumber)+ " x 12" );

			
		}
}

