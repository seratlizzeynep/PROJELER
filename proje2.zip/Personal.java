package d;

public class Personal {


			
	double interest=0.3995,
			risk;

		public double calculateInterestPersonal(int capital, Person per) 
		{
			this.interest=(capital+this.risk)*(this.interest+1);
			
			
			return 
					this.interest;
		}
		
		public double creditRiskFeePersonal(int age, double capital) {
			
			if(age>55) {
				
				this.risk=(age-55)*0.02*capital*(this.interest/12);
				
			}
			else
				this.risk= 0;
			
			return 
					this.risk;
		}

		public void restructuringLoan(int newMonthNumber, Person person, double...remainingInstallments) {
			// TODO Auto-generated method stub
			
			double x= remainingInstallments.length*remainingInstallments[0];
			
			double y= person.installment-x;
			
			System.out.println("New Personal Loan Repayment will be: " + y);
			System.out.println("Your new payments will be: "+ (y/newMonthNumber)+ " x 24" );
		}
		
		


	}

		
	

