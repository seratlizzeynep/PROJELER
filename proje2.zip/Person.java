package d;

public class Person {

		private String name;
		private int age;
		private  String surname;
		private double salary;
		String type;
		double installment;
		public Person(String name, String surName, 
				int age, 
				double salary) {
			
			this.setName(name);
			this.setSurname(surName);
			this.setSalary(salary);
			this.setAge(age);
		}
		
		

		public String getName() {
			return name;
		}



		public void setName(String name) {
			this.name = name;
		}



		public String getSurname() {
			return surname;
		}



		public void setSurname(String surname) {
			this.surname = surname;
		}



		public int getAge() {
			return age;
		}



		public void setAge(int age) {
			this.age = age;
		}



		public double getSalary() {
			return salary;
		}



		public void setSalary(double salary) {
			this.salary = salary;
		}
		
		public void applyForLoan(Person per, int capital, int  month, String loanType)
		{
			boolean b = false;
			this.type=loanType;
			
			if(loanType.equals("Mortgage")) {
				
				if(this.salary<installment)
				{
					b=false;
					
				}
				else b=true;
				
				this.printCreditResult(b, capital, per, installment, month);
			}
			
			if(loanType.equals("Personal")) {
				Personal personal = new Personal();
				personal.creditRiskFeePersonal(age, capital);
				double installment=personal.calculateInterestPersonal(capital, per)/month;
			
				
				if(this.salary<installment) {
					b=false;
				
				}
				else b=true;
				
				this.printCreditResult(b, capital, per, installment, month);
				
			}
			
			if(loanType.equals("Vehicle")) {
				Vehicle vehicle = new Vehicle();
				vehicle.creditRiskFeeVehicle(age, capital);
				
		double installment=vehicle.calculateInterestVehicle(capital, per)/month;
				
				if(this.salary<installment) 
				{
					b = false;
					
				}
				else 
				
					b=true;
			}
				this.printCreditResult(b, capital, per, installment, month);
		}
			
		
		
		public void printCreditResult(Boolean b, int capital, Person p, double installment, int month) {
			if (b==true)
			{
				System.out.println("Congratulations "+name+" "+surname+"!");
				System.out.println("Your "+type+" credit application: "+capital+" has been accepted!");
				System.out.println("Your monthly payment will be: "+installment+" x "+month);
				System.out.println("Repayment costs = "+installment*month);
				System.out.println();
				
			}
			
			else {
				System.out.println("We are sorry "+name+" "+surname+"!");
				System.out.println("Your "+type+" credit application "+capital+" has been rejected because your salary is "
						+ "lower than the installments!");
				System.out.println("Your salary: "+salary+" < " +installment);
				System.out.println();
			}
		
}
		}