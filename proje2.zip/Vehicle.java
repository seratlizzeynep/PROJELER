package d;

public class Vehicle {
	
	double interest=0.4495,
			risk;
	
	public double calculateInterestVehicle(int capital, Person person) {
		this.interest=(capital+this.risk)*(this.interest+1);
		return this.interest;
	}
	
	public double creditRiskFeeVehicle(int age, double capital) {
	
		if(age<=60 && age>=35) 
		{
			this.risk=0;
		}
		else {
			this.risk = 0.11*capital*(this.interest/12);
		}
		return this.risk;
	}

	public void restructuringLoan(int newMonthNumber, Person person, double...remainingInstallments) 
	{
		// TODO Auto-generated method stub
		
		double x= remainingInstallments.length*remainingInstallments[0];
		
		double y= person.installment-x;
		
		System.out.println("New Vehicle Loan Repayment will be: " + y);
		System.out.println("Your new payments will be: "+ (y/newMonthNumber)+ " x 24" );
	}	

}
