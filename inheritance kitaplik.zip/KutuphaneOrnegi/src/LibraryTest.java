
public class LibraryTest {
    public static void main(String[] args) {
        Book book1 = new Book("The Great Gatsby", "F. Scott Fitzgerald", 180);
        Magazine mag1 = new Magazine("National Geographic", "Editorial Team", "April 2024");

        System.out.println(book1.getDetails());
        System.out.println(mag1.getDetails());

        book1.checkOut();
        book1.returnItem();
        mag1.checkOut();
    }
}