
public class Magazine extends LibraryItem {
    private String issueDate;

    
    public Magazine(String title, String author, String issueDate) {
        super(title, author);
        this.issueDate = issueDate;
    }

    @Override
    public String getDetails() {
        return super.getDetails() + ", Issue Date: " + issueDate;
    }
}
