
public class LibraryItem {
    private String title;
    private String author;
    private boolean isAvailable;
    
   
    public LibraryItem(String title, String author) {
        this.title = title;
        this.author = author;
        this.isAvailable = true;
    }

   
    public void checkOut() {
        if (isAvailable) {
            isAvailable = false;
            System.out.println(title + " has been checked out.");
        } else {
            System.out.println(title + " is not available.");
        }
    }

    public void returnItem() {
        isAvailable = true;
        System.out.println(title + " has been returned.");
    }

    public String getDetails() {
        return "Title: " + title + ", Author: " + author + ", Available: " + isAvailable;
    }
}
