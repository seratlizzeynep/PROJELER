
public class StudentManage {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		
		Student student1= new Student (70, "Sam",123456, "Second" );
		//create student1 for Sam grade:70, Student Number:123456 and Student Class= Second
		
		//create student2 for Sarah grade:40, Student Number:98745 and Student Class= Third
		
		Student student2= new Student (40,"Sarah", 98745, "Third");
		
		System.out.println("------Student 1------");
		
		//call PassStatus and AddBonusGrade for student1 
		student1.AddBonusGrade();
		student1.PassStatus();
		
		//change the class for studnet1 as Third
		student1.withdraw("Third");
		
		//print summary for student1
		
		System.out.println(student1);
		
		System.out.println("------Student 2------");
		

		//call PassStatus and AddBonusGrade for student2 

		student2.AddBonusGrade();
		student2.PassStatus();
		
		//change the class for studnet2 as Second
		student2.withdraw("Second");
		
		//print summary for student2
		System.out.println(student2);
	}

}