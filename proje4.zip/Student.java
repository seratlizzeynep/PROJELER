public class Student {
	
	private double grade;
	private String name;
	private long studentId;
	private String StudentClass;
	// ---------------------------------------------------------------
	// Constructor -- initializes grade, name, and Student number
	// ---------------------------------------------------------------
	
	
	// --------------------------------
	// Setting Pass Status by grade 
	// --------------------------------
	
	public Student (double grade, String name, long studentId, String StudentClass) {
		this.grade=grade;
		this.name=name;
		this.studentId= studentId;
		this.StudentClass= StudentClass;
	}
	public Student(int i, String string, Object println) {
		// TODO Auto-generated constructor stub
	}
	public void PassStatus()
	{
		//add body of PassStatus
		if (grade <50) {
			System.out.println("You fail this course :(") ;
	
		}
		
		else  
				System.out.println("You pass this course :)");
				
			}
			
	
	public String getName() {
		return name;
	}

	// ------------------------
	// Returns grade.
	// ------------------------
	public double getGrade()
	{
		return grade;
	}
	// --------------------------------------------------------------------
	// Returns a string containing the name, student number, and grade.
	// -----------------------------------------------------------------
	public long getStudentId() {
		return studentId;
	}


	public void setStudentId(long studentId) {
		this.studentId = studentId;
	}


	public String getStudentClass() {
		return StudentClass;
	}


	public void setStudentClass(String studentClass) {
		StudentClass = studentClass;
	}


	public void setGrade(double grade) {
		this.grade = grade;
	}


	public void setName(String name) {
		this.name = name;
	}

	public String toString() 
	{
		
		return (name +" " + studentId +" "+ grade);
		//add body of toString
	}

	// -------------------------------------------------- 
	// Add 10 percentage of grade as a bonus grade .
	// --------------------------------------------------
	
	
	public void AddBonusGrade()
	{
		grade=grade + grade*0.1;
		
		System.out.println("New grade after adding bonus grade is " + grade);
	
   	}
	// --------------------------------------------
	//Change class of student
	// --------------------------------------------
	public void changeClass(String newClass)
	
	{
		
		this.StudentClass=newClass;
		
		
	}
	public void withdraw(String string) {
		// TODO Auto-generated method stub
		
	}
}


