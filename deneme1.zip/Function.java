public class Function {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		double a,b;
		double result
		
		
	}

}
