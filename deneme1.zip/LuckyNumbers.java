import java.util.Random;

public class LuckyNumbers {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		
		Random generator = new Random();
		int lucky1, lucky2, lucky3;
		
		lucky1 = generator.nextInt(30)+70;
		
		
		lucky2 = generator.nextInt(21)+50;
		
		lucky3 = (int) (generator.nextInt(19)+70);
		System.out.println ("Your lucky numbers are " + lucky1 + ", " + lucky2
		+ ", and " + lucky3);
	}

}
