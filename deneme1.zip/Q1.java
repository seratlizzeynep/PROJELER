public class Q1 {
public static void main (String[] args){
String CarModel = new String ("Nissan Micra");
String Ownername = new String("Jennifer Smith");// part (a)
int stringLength;
String change1, change2, change3;
stringLength= CarModel.length(); // part (b)
System.out.println (CarModel + " has " + stringLength + " characters.");
change1 = Ownername.toUpperCase(); // part (c)
change2 = ; 
change3 = CarModel.toLowerCase(); // part (e)
System.out.println ("After changing E to 3 : " + change2);
System.out.println ("The final string is : " + change3);
}
}