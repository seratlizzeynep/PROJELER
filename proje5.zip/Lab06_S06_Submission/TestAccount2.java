import java.util.Scanner;

public class TestAccount2 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		Scanner dyg= new Scanner(System.in);
		String firstname,second,third;
		
		Account acct,acct2,acct3;
		
		System.out.println("Enter name for first player: ");
		firstname=dyg.next();
		
		System.out.println("First player");
		acct= new Account(100,firstname);
		
		System.out.println(acct.toString());
		System.out.println();
		
		System.out.println("Enter name for second player: ");
		second=dyg.next();
		System.out.println("Second player");
		acct2= new Account(100,second);
		System.out.println(acct2.toString());
		System.out.println();
		
		System.out.println("Enter name for third player: ");
		third=dyg.next();
		System.out.println("Third player");
		acct3= new Account(100,third);
		System.out.println(acct3.toString());
		System.out.println();
		
		
		
		
		
		
		
		
		System.out.println("Trying to combinating second and third accounts.");
		Account.combine(acct2,acct3);
		
		if (acct==null) {
			System.out.println("Sorry, accounts with different names cannot be combinated.");
		}
		else {
			System.out.println("Result account is");
			System.out.println(acct.toString());
		}
			
			
		
		
	}

}
