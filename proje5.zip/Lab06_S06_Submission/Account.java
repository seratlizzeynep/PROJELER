import java.lang.Math;
public class Account
{
	private double elo;
	private String name;
	private long acctNum;

	public Account(double initBal, String playerName, long number) {
		this.elo=initBal;
		this.name=playerName;
		this.acctNum=number;
	}
	
	public Account (double initBal, String playerName) {
		this.elo=initBal;
		this.name=playerName;
		this.acctNum=(long)(Math.random() * 999999999);
	}
	public Account (String playerName) {
		this.name=playerName;
		this.acctNum=(long)(Math.random() * 999999999);
		elo=0;
	}
	 public static Account AccountRandom (Account acct, Account acct2) {
		 if (acct.getName().equals(acct2.getName()) & acct.acctNum != acct2.getAcctNum());
		acct= new Account (acct.getelo() +acct2.getelo()/2, acct.getName());
		 return acct;
		 
		 
	 }
	
	 
	
	
	
	double getElo() {
		return elo;
	}

	public void setElo(double elo) {
		this.elo = elo;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public long getAcctNum() {
		return acctNum;
	}

	public void setAcctNum(long acctNum) {
		this.acctNum = acctNum;
	}

	public void lose(double amount){
		if (elo >= amount)
		elo -= amount;
		else
		System.out.println("Elo is already zero.");
}
	public void win(double amount){
	elo += amount;
}
	public double getelo(){
		return elo;
}
	public String toString(){
		return "Name:" + name + "\nAcct #: " + acctNum +
			"\nElo: " + elo;
}

	public static void combine(Account acct2, Account acct3) {
		// TODO Auto-generated method stub
		
	}

}
